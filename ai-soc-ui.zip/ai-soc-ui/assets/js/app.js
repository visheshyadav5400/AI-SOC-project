/* ============================================================
   AI-SOC — overview page logic
   Live simulation: ticking throughput, streaming alerts, filters.
   ============================================================ */

(function () {
  'use strict';

  var D = window.SOC_DATA;
  var state = {
    alerts: D.alerts.slice(),
    series: D.series.slice(),
    filter: 'all',       // all | critical | high
    query: '',
    nextId: 2848,
    evtRate: D.series[D.series.length - 1]
  };

  /* theme handled by shell.js */

  /* ---------- clock ---------- */
  function tickClock() {
    var el = document.getElementById('clock');
    if (!el) return;
    var now = new Date();
    el.textContent = now.toLocaleString('en-IN', {
      weekday: 'short', day: 'numeric', month: 'short',
      hour: '2-digit', minute: '2-digit', hour12: false
    }) + ' IST';
  }
  tickClock();
  setInterval(tickClock, 30000);

  /* ---------- events/sec jitter ---------- */
  function tickRate() {
    var drift = Math.round((Math.random() - 0.45) * 60);
    state.evtRate = Math.max(650, Math.min(1600, state.evtRate + drift));
    var kpi = document.getElementById('kpi-eps');
    var now = document.getElementById('chart-now');
    if (kpi) kpi.textContent = state.evtRate.toLocaleString('en-IN');
    if (now) now.textContent = 'now · ' + state.evtRate.toLocaleString('en-IN') + ' e/s';
  }
  setInterval(tickRate, 2000);

  /* ---------- throughput chart ---------- */
  function renderChart() {
    var svg = document.getElementById('chart');
    if (!svg) return;
    var s = state.series;
    var W = 640, left = 34, right = 628, baseY = 148;
    var min = 400, max = 1700;
    var step = (right - left) / (s.length - 1);
    var pts = s.map(function (v, i) {
      var x = left + i * step;
      var y = baseY - ((v - min) / (max - min)) * 110;
      return [Math.round(x), Math.round(y)];
    });
    var line = pts.map(function (p, i) { return (i === 0 ? 'M' : 'L') + p[0] + ' ' + p[1]; }).join(' ');
    var area = line + ' L' + right + ' ' + baseY + ' L' + left + ' ' + baseY + ' Z';
    var last = pts[pts.length - 1];
    svg.querySelector('.area').setAttribute('d', area);
    svg.querySelector('.line').setAttribute('d', line);
    var dotEl = svg.querySelector('.dot-now');
    dotEl.setAttribute('cx', last[0]);
    dotEl.setAttribute('cy', last[1]);
  }
  renderChart();
  setInterval(function () {
    state.series.push(state.evtRate);
    state.series.shift();
    renderChart();
  }, 6000);

  /* ---------- alert queue ---------- */
  var SEV_RANK = { critical: 0, high: 1, medium: 2, low: 3 };

  function alertRow(a, isNew) {
    var row = document.createElement('a');
    row.href = 'triage.html?id=' + encodeURIComponent(a.id);
    row.className = 'tr' + (a.sev === 'critical' ? ' selected' : '') + (isNew ? ' flash' : '');
    row.innerHTML =
      '<span class="sev sev-' + a.sev + '">' + a.sev.toUpperCase() + '</span>' +
      '<span class="cell-alert">' + a.title + '</span>' +
      '<span class="cell-dim">' + a.tech + '</span>' +
      '<span class="cell-dim">' + a.entity + '</span>' +
      '<span class="engines">' + a.engines.map(function (e) {
        var cls = e === 'RULE' ? 'eng-rule' : (e === 'ML' ? 'eng-ml' : 'eng-ai');
        return '<span class="eng ' + cls + '">' + e + '</span>';
      }).join('') + '</span>' +
      '<span class="risk" style="color: var(--' + (a.sev === 'critical' ? 'crit' : a.sev === 'high' ? 'high' : a.sev === 'medium' ? 'med' : 'low') + ')">' + a.risk + '</span>' +
      '<span class="cell-time">' + a.time + '</span>';
    return row;
  }

  function renderQueue(newId) {
    var body = document.getElementById('queue-body');
    if (!body) return;
    body.innerHTML = '';
    var q = state.query.toLowerCase();
    var shown = state.alerts
      .filter(function (a) {
        if (state.filter !== 'all' && a.sev !== state.filter) return false;
        if (q && (a.title + a.tech + a.entity).toLowerCase().indexOf(q) === -1) return false;
        return true;
      })
      .sort(function (a, b) { return SEV_RANK[a.sev] - SEV_RANK[b.sev] || b.risk - a.risk; });
    shown.forEach(function (a) { body.appendChild(alertRow(a, a.id === newId)); });

    var counts = { all: state.alerts.length, critical: 0, high: 0 };
    state.alerts.forEach(function (a) {
      if (a.sev === 'critical') counts.critical++;
      if (a.sev === 'high') counts.high++;
    });
    var cAll = document.getElementById('chip-all');
    var cCrit = document.getElementById('chip-critical');
    var cHigh = document.getElementById('chip-high');
    if (cAll) cAll.textContent = 'All ' + counts.all;
    if (cCrit) cCrit.textContent = 'Critical ' + counts.critical;
    if (cHigh) cHigh.textContent = 'High ' + counts.high;
    var navCount = document.getElementById('nav-alert-count');
    if (navCount) navCount.textContent = String(counts.all);
  }
  renderQueue();

  // live feed: a new alert arrives every ~10s
  var poolIdx = 0;
  setInterval(function () {
    var tpl = D.pool[poolIdx % D.pool.length];
    poolIdx++;
    var now = new Date();
    var a = {
      id: 'ALR-' + state.nextId++,
      sev: tpl.sev, title: tpl.title, tech: tpl.tech, entity: tpl.entity,
      engines: tpl.engines, risk: tpl.risk,
      time: ('0' + now.getHours()).slice(-2) + ':' + ('0' + now.getMinutes()).slice(-2)
    };
    state.alerts.unshift(a);
    if (state.alerts.length > 12) state.alerts.pop();
    renderQueue(a.id);
  }, 10000);

  // filter chips
  ['all', 'critical', 'high'].forEach(function (f) {
    var chip = document.getElementById('chip-' + f);
    if (!chip) return;
    chip.addEventListener('click', function () {
      state.filter = state.filter === f ? 'all' : f;
      ['all', 'critical', 'high'].forEach(function (g) {
        var el = document.getElementById('chip-' + g);
        if (el) el.classList.toggle('off', state.filter !== 'all' && state.filter !== g && g !== 'all');
      });
      renderQueue();
    });
  });

  // search
  var search = document.getElementById('search');
  if (search) {
    search.addEventListener('input', function () {
      state.query = search.value.trim();
      renderQueue();
    });
  }

  /* ---------- engine bars ---------- */
  document.querySelectorAll('.bar-fill[data-pct]').forEach(function (el) {
    requestAnimationFrame(function () { el.style.width = el.getAttribute('data-pct') + '%'; });
  });
})();
