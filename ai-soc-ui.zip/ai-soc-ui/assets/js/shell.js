/* ============================================================
   AI-SOC — shared shell: sidebar, theme, toast
   Each page sets <body data-page="..."> and includes an empty
   <nav class="sidebar" id="sidebar"> that this script fills.
   ============================================================ */

(function () {
  'use strict';

  var ICONS = {
    overview: '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><rect x="1.5" y="1.5" width="5.5" height="5.5" rx="1.5" stroke="currentColor" stroke-width="1.4"/><rect x="9" y="1.5" width="5.5" height="5.5" rx="1.5" stroke="currentColor" stroke-width="1.4"/><rect x="1.5" y="9" width="5.5" height="5.5" rx="1.5" stroke="currentColor" stroke-width="1.4"/><rect x="9" y="9" width="5.5" height="5.5" rx="1.5" stroke="currentColor" stroke-width="1.4"/></svg>',
    alerts: '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M8 1.8c-2.6 0-4.2 1.8-4.2 4.4 0 1.9-.5 3-1.1 3.9-.3.4 0 1 .5 1h9.6c.5 0 .8-.6.5-1-.6-.9-1.1-2-1.1-3.9 0-2.6-1.6-4.4-4.2-4.4Z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/><path d="M6.4 13.4a1.7 1.7 0 0 0 3.2 0" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg>',
    incidents: '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M8 1.5c1.2 2.2 3.1 2.6 3.1 5.3A3.1 3.1 0 0 1 8 10a3.1 3.1 0 0 1-3.1-3.2C4.9 4.1 6.8 3.7 8 1.5Z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/><path d="M3.4 10.6a4.9 4.9 0 0 0 9.2 0" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg>',
    attack: '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><rect x="1.5" y="1.5" width="13" height="13" rx="2" stroke="currentColor" stroke-width="1.4"/><path d="M1.5 6h13M1.5 10.5h13M6 1.5v13M10.5 1.5v13" stroke="currentColor" stroke-width="1.1"/></svg>',
    hunt: '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><circle cx="7" cy="7" r="5" stroke="currentColor" stroke-width="1.4"/><path d="M10.8 10.8 14.2 14.2" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg>',
    playbooks: '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M4 2.2 12.8 8 4 13.8V2.2Z" stroke="currentColor" stroke-width="1.4" stroke-linejoin="round"/></svg>',
    settings: '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true"><circle cx="8" cy="8" r="2.2" stroke="currentColor" stroke-width="1.4"/><path d="M8 1.6v2M8 12.4v2M1.6 8h2M12.4 8h2M3.5 3.5l1.4 1.4M11.1 11.1l1.4 1.4M12.5 3.5l-1.4 1.4M4.9 11.1 3.5 12.5" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/></svg>'
  };

  var NAV = [
    { id: 'overview', label: 'Overview', href: 'index.html' },
    { id: 'alerts', label: 'Alerts', href: 'triage.html', count: true },
    { id: 'incidents', label: 'Incidents', href: 'incidents.html' },
    { id: 'attack', label: 'ATT&amp;CK matrix', href: 'attack.html' },
    { id: 'hunt', label: 'Threat hunt', href: 'hunt.html' },
    { id: 'playbooks', label: 'Playbooks', href: 'playbooks.html' },
    { id: 'settings', label: 'Settings', href: 'settings.html' }
  ];

  var page = document.body.getAttribute('data-page') || '';

  function renderSidebar() {
    var el = document.getElementById('sidebar');
    if (!el) return;
    var html =
      '<div class="brand">' +
      '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" role="img" aria-label="AI-SOC shield logo"><path d="M12 2 20 5.5V11c0 5-3.4 9.3-8 11-4.6-1.7-8-6-8-11V5.5L12 2Z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M8.5 12l2.3 2.4L15.5 9.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
      '<span class="brand-name">AI-SOC</span><span class="env-badge">LAB</span></div>' +
      '<div class="nav">' +
      NAV.map(function (n) {
        var active = n.id === page;
        return '<a href="' + n.href + '"' + (active ? ' class="active" aria-current="page"' : '') + '>' +
          ICONS[n.id] + n.label +
          (n.count ? '<span class="count" id="nav-alert-count">6</span>' : '') +
          '</a>';
      }).join('') +
      '</div>' +
      '<div class="sidebar-footer">' +
      (page === 'overview'
        ? '<div class="health"><span class="kpi-label">PIPELINE HEALTH</span>' +
          '<div class="health-row"><span class="dot"></span>Kafka <span class="mono" style="font-size:11px">1.2k e/s</span></div>' +
          '<div class="health-row"><span class="dot"></span>OpenSearch <span class="mono" style="font-size:11px">OK</span></div>' +
          '<div class="health-row"><span class="dot"></span>ML models <span class="mono" style="font-size:11px">3 live</span></div>' +
          '<div class="health-row"><span class="dot warn"></span>LLM triage <span class="mono" style="font-size:11px">2.4s avg</span></div></div>'
        : '') +
      '<div class="user"><span class="avatar">AD</span>' +
      '<span><span class="user-name" style="display:block">Admin</span><span class="user-role">Administrator</span></span></div>' +
      '</div>';
    el.innerHTML = html;
  }
  renderSidebar();

  /* ---------- theme ---------- */
  function setTheme(t) {
    document.documentElement.setAttribute('data-theme', t);
    try { localStorage.setItem('aisoc-theme', t); } catch (e) { /* file:// may block storage */ }
  }
  try {
    var saved = localStorage.getItem('aisoc-theme');
    if (saved) document.documentElement.setAttribute('data-theme', saved);
  } catch (e) { /* ignore */ }
  var themeBtn = document.getElementById('theme-toggle');
  if (themeBtn) {
    themeBtn.addEventListener('click', function () {
      var next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
      setTheme(next);
    });
  }

  /* ---------- toast helper (shared) ---------- */
  window.socToast = function (msg) {
    var t = document.getElementById('toast');
    if (!t) {
      t = document.createElement('div');
      t.id = 'toast';
      t.className = 'toast';
      t.setAttribute('role', 'status');
      document.body.appendChild(t);
    }
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(window.__socToastTimer);
    window.__socToastTimer = setTimeout(function () { t.classList.remove('show'); }, 2600);
  };
})();
