/* ============================================================
   AI-SOC — mock data layer
   Replace with fetch() calls to your real API later, e.g.:
     const alerts = await (await fetch('/api/alerts')).json();
   ============================================================ */

window.SOC_DATA = {
  // Initial alert queue (risk-ranked)
  alerts: [
    { id: 'ALR-2847', sev: 'critical', title: 'Credential dumping via LSASS memory access', tech: 'T1003.001', entity: 'WIN-SRV-01 · svc-backup', engines: ['RULE', 'AI'], risk: 94, time: '14:32' },
    { id: 'ALR-2846', sev: 'high', title: 'SSH brute force — 240 failures in 3 min', tech: 'T1110.001', entity: 'ubuntu-web-01', engines: ['RULE'], risk: 81, time: '14:29' },
    { id: 'ALR-2845', sev: 'high', title: 'Anomalous logon hour + new geolocation', tech: 'T1078', entity: 'priya.k · VPN', engines: ['ML'], risk: 76, time: '14:21' },
    { id: 'ALR-2844', sev: 'medium', title: 'Base64-encoded PowerShell command', tech: 'T1059.001', entity: 'WIN-SRV-02 · j.mathew', engines: ['RULE'], risk: 58, time: '14:05' },
    { id: 'ALR-2843', sev: 'medium', title: 'Unusual outbound beacon interval (28s fixed)', tech: 'T1071', entity: '10.0.4.17 → 185.220.101.4', engines: ['ML'], risk: 54, time: '13:58' },
    { id: 'ALR-2842', sev: 'low', title: 'New scheduled task registered', tech: 'T1053.005', entity: 'WIN-DEV-03', engines: ['RULE'], risk: 31, time: '13:44' }
  ],

  // Pool of alerts the live simulation draws from
  pool: [
    { sev: 'high', title: 'Possible Kerberoasting — mass TGS requests', tech: 'T1558.003', entity: 'WIN-DC-01 · svc-sql', engines: ['RULE', 'ML'], risk: 79 },
    { sev: 'medium', title: 'Rare parent-child pair: winword → cmd.exe', tech: 'T1204.002', entity: 'WIN-FIN-04 · a.rao', engines: ['ML'], risk: 61 },
    { sev: 'low', title: 'Nmap SYN scan detected from lab subnet', tech: 'T1046', entity: '10.0.9.5', engines: ['RULE'], risk: 28 },
    { sev: 'medium', title: 'DNS query burst to newly-registered domain', tech: 'T1568', entity: 'ubuntu-web-01', engines: ['ML'], risk: 57 },
    { sev: 'high', title: 'Wazuh FIM: /etc/shadow modified', tech: 'T1003.008', entity: 'ubuntu-db-01 · root', engines: ['RULE'], risk: 83 },
    { sev: 'low', title: 'New local admin account created', tech: 'T1136.001', entity: 'WIN-DEV-03', engines: ['RULE'], risk: 35 }
  ],

  // Event-throughput series (events/sec), oldest → newest
  series: [910, 960, 905, 1020, 980, 1110, 1060, 1190, 1140, 1265, 1225, 1284],

  // Detections by engine (24h)
  engines24h: [
    { name: 'Sigma rules', value: 142 },
    { name: 'ML anomaly', value: 61 },
    { name: 'UEBA', value: 27 }
  ],

  // ATT&CK heatmap: 7 tactics × 3 technique rows; 0 = no coverage (gap)
  heatmap: {
    tactics: ['INIT', 'EXEC', 'PERS', 'PRIV', 'CRED', 'LAT', 'EXFIL'],
    cells: [
      2, 4, 1, 2, 4, 1, 0,
      1, 2, 0, 1, 5, 2, 0,
      2, 0, 1, 1, 2, 0, 1
    ]
  },

  // Triage detail (the demo-star alert)
  triage: {
    id: 'ALR-2847',
    sev: 'CRITICAL',
    title: 'Credential dumping via LSASS memory access',
    firstSeen: '14:32:07 IST',
    rawEvents: 14,
    tech: 'T1003.001 · Credential Access',
    host: 'WIN-SRV-01',
    user: 'svc-backup',
    dst: '185.220.101.4',
    risk: 94,
    scores: { sigma: 1.0, ml: 0.87, ueba: 0.78 },
    confidence: 0.91,
    model: 'llama-3.1-8b · RAG · 2.4s'
  }
};
