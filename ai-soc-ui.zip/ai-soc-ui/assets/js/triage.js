/* ============================================================
   AI-SOC — triage page logic
   Toast feedback on response actions + animated score bars.
   ============================================================ */

(function () {
  'use strict';

  /* theme handled by shell.js */

  /* ---------- toast ---------- */
  var toast = document.getElementById('toast');
  var toastTimer = null;
  function showToast(msg) {
    if (!toast) return;
    toast.textContent = msg;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toast.classList.remove('show'); }, 2600);
  }

  var approve = document.getElementById('btn-approve');
  if (approve) {
    approve.addEventListener('click', function () {
      approve.disabled = true;
      approve.textContent = 'Block applied ✓';
      approve.style.opacity = '0.65';
      var pending = document.getElementById('pending-row');
      if (pending) {
        pending.classList.remove('pending');
        pending.querySelector('.when').textContent = 'analyst · just now';
      }
      showToast('Playbook executed — 185.220.101.4 blocked at the firewall.');
    });
  }
  var escalate = document.getElementById('btn-escalate');
  if (escalate) {
    escalate.addEventListener('click', function () {
      showToast('Escalated — incident INC-0211 created and assigned to Tier-2.');
    });
  }
  var fp = document.getElementById('btn-fp');
  if (fp) {
    fp.addEventListener('click', function () {
      showToast('Marked false positive — feedback queued for ML retraining.');
    });
  }

  /* ---------- animate score bars ---------- */
  document.querySelectorAll('.bar-fill[data-pct]').forEach(function (el) {
    requestAnimationFrame(function () { el.style.width = el.getAttribute('data-pct') + '%'; });
  });
})();
