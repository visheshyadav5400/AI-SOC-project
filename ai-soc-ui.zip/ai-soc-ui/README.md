# AI-SOC Analyst Console — UI

Light-theme front end for the **AI-SOC: Intelligent Threat Detection and Real-Time Log Analysis** project.
Plain HTML/CSS/JS — no build step, no dependencies. A dark theme is included as a toggle (moon button, top right).

## Run it

**Option 1 — just open it**

Double-click `index.html`. Everything works from the file system.

**Option 2 — local server (recommended)**

```bash
cd ai-soc-ui
python -m http.server 8000
# open http://localhost:8000
```

## What to test

| Where | What happens |
| --- | --- |
| Overview — LIVE badge & Events/sec | Value jitters every 2s; chart appends a new point every 6s |
| Overview — Alert queue | A new alert streams in every ~10s with a flash animation; counters update |
| Overview — chips & search | `Critical` / `High` chips and the search box filter the queue live |
| Overview — any alert row | Click → opens the triage page |
| Triage — Approve firewall block | Pending action flips to done + toast confirmation |
| Triage — Escalate / False positive | Toast feedback (false-positive feedback is where ML retraining hooks in) |
| Moon button (both pages) | Light ↔ dark theme, remembered across pages |

## Structure

```
ai-soc-ui/
├── index.html          # Overview dashboard (KPIs, throughput chart, alert queue, ATT&CK heatmap)
├── triage.html         # Alert detail: AI triage narrative, evidence timeline, response actions
├── incidents.html      # Case list with status, owner, age
├── attack.html         # Full ATT&CK coverage matrix (detected / rule-ready / gap)
├── hunt.html           # Threat-hunt query bar, saved hunts, mock results
├── playbooks.html      # Response playbooks with dry-run buttons
├── settings.html       # Data sources, thresholds, AI-triage model config
├── assets/
│   ├── css/styles.css  # All styling; light theme default, dark via [data-theme="dark"]
│   └── js/
│       ├── shell.js    # Shared sidebar, theme toggle, toast helper (edit nav/user here)
│       ├── data.js     # Mock data layer — swap for real API calls
│       ├── app.js      # Overview logic: live simulation, chart, filters
│       └── triage.js   # Triage logic: action buttons, toasts
```

The sidebar and signed-in user ("Admin") are defined once in `assets/js/shell.js`.

## Wiring the real backend later

All data enters through `assets/js/data.js` (`window.SOC_DATA`). To connect the real pipeline:

1. Serve alerts from your FastAPI service, e.g. `GET /api/alerts`, `GET /api/alerts/{id}`.
2. In `app.js`, replace the pool-based simulation with polling or a WebSocket:
   ```js
   const res = await fetch('/api/alerts');
   state.alerts = await res.json();
   renderQueue();
   ```
3. The triage page reads `?id=` from the URL — fetch `/api/alerts/{id}` and fill the same elements.

Theme tokens live at the top of `styles.css` (`:root` = light, `[data-theme="dark"]` = dark), so restyling or matching a brand is a one-block change.
